---
name: active-living-design
description: Use this skill to generate well-branded interfaces and assets for Active Living (marca personal de Juanma Lemus), either for production or throwaway prototypes/mocks/etc. Contains essential design guidelines, colors, type, fonts, assets, and UI kit components for prototyping.
user-invocable: true
---

Read the README.md file within this skill, and explore the other available files.
If creating visual artifacts (slides, mocks, throwaway prototypes, etc), copy assets out and create static HTML files for the user to view. If working on production code, you can copy assets and read the rules here to become an expert in designing with this brand.
If the user invokes this skill without any other guidance, ask them what they want to build or design, ask some questions, and act as an expert designer who outputs HTML artifacts _or_ production code, depending on the need.

Reglas duras de Active Living: negro #0A0A0A dominante, blanco para texto, lima #C6F542 como única chispa (nunca superficie grande); Anton solo en MAYÚSCULAS para display, Archivo para cuerpo y labels; plano, radius 0, sin sombras; glifos permitidos: → ↓ /; voz directa y honesta, nunca gurú; el enemigo de la marca es "enamorarse del plan para no arriesgarse con la acción"; sign-off: "Lo hago de todos modos."
