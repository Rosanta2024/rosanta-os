# Notas internas — metodología de referencia (resumen propio, no reproducir textos fuente)

Fuentes del usuario (uploads/): Anti-Brand Sprint Workbook + Visual Storytelling Playbook (The Passive Rebel, © — usar solo como marco conceptual, redactar todo original).

## Estructura del método anti-brand (para el formato del doc)
1. **Atmósfera** — la sensación al entrar al mundo de la marca; 3 emociones objetivo; qué gente pertenece y quién no; qué se rechaza.
2. **Vibe visual** — moodboard → paleta (primario / secundario / acento CTA / neutro); test: "¿esto se siente como yo?".
3. **Hooks / interrupción de patrón** — 4 niveles: pausa → interés → promesa de transformación → acción/urgencia. Familias: confesión, contraria, número específico, behind-the-scenes, transformación.
4. **Messaging / historia** — arco: Setup (dónde estaba) → Struggle (el desorden) → Shift (el giro) → Solution (lo que funcionó) → Result (dónde estoy). El cliente/audiencia es el héroe, la marca es el guía.
5. **Rebellious edge / el enemigo** — la marca se define POR algo al estar CONTRA algo: prácticas de la industria que rechaza. Formato: "Mi enemigo es X / porque causa Y / yo creo en Z". Statements: "Todos dicen ___, yo creo ___".

Extras del método: arquetipo (Rebel, Creator, Sage…), 2-3 elementos firma (tratamiento tipográfico, combinación de color, encuadre, catchphrase), word bank de voz ("mi voz es… / sueno como… / nunca sueno…").

## Visual storytelling (para frames de historia)
- Emoción primero; una pieza = un mensaje = un CTA.
- Story map emocional: dolor → nueva perspectiva → deseo de cambio → herramienta → transformación → alivio.
- Carruseles = argumento por slides; diseñar para screenshot (cada slide funciona sola).
- B/N + un color de disrupción; textura/grano; composición confiada; blancos generosos; imperfección > pulido.
- 7 pecados a evitar: perfección, marca como protagonista, solo triunfos, arte sobre claridad, asumir audiencia, visuales aburridos, decir todo a la vez.

## Tokens confirmados por Juanma
- Colores: negro, blanco, lima #C6F542.
- Tipografía: Anton (display) + Archivo (cuerpo/labels).
- Componentes pedidos: títulos, eyebrows, frames de historia (9:16), etc.

## Pendiente de Juanma (preguntado en formulario)
nombre de marca, enemigo/edge, arquetipo, 3 emociones, frases firma, usos principales, tipos de frames.
