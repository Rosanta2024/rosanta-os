Bloque antes→después (el formato natural de la marca): patrón viejo tachado, flecha lima, patrón corregido.

```jsx
<AntesDespues antes="Afinar el plan una semana más" despues="Publicar la versión imperfecta hoy" />
<AntesDespues dir="row" size={24} antes="Preparar" despues="Ejecutar" />
```
