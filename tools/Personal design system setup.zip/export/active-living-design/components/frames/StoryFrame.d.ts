import * as React from 'react';
/**
 * Frame de historia IG (lienzo 1080x1920 autoescalado a `width`) con los layouts de la marca.
 * @startingPoint section="Frames" subtitle="Historia IG 9:16 — hook, foto, antes-después, quote o CTA" viewport="270x480"
 */
export interface StoryFrameProps {
  /** 'hook' (default) | 'foto' (texto sobre foto) | 'antes-despues' | 'quote' | 'cta' */
  kind?: 'hook' | 'foto' | 'antes-despues' | 'quote' | 'cta';
  eyebrow?: string;
  /** Texto principal (hook/título). */
  title?: string;
  /** Palabra(s) final(es) del título con marcador lima. */
  highlight?: string;
  /** Línea secundaria bajo el título. */
  sub?: string;
  /** Copy del CTA (kinds 'cta' y 'antes-despues'). */
  cta?: string;
  /** Foto de fondo (kind 'foto'); sin URL muestra placeholder. */
  imageUrl?: string;
  antes?: string;
  despues?: string;
  /** Texto del quote (kind 'quote'). */
  quote?: string;
  /** Sign-off: string propio, o `false` para ocultarlo. Default "Lo hago de todos modos." */
  firma?: string | false;
  /** Ancho renderizado en px (alto = width*16/9). Default 270. */
  width?: number;
  /** Contenido libre (reemplaza el layout del kind). */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function StoryFrame(props: StoryFrameProps): JSX.Element;
