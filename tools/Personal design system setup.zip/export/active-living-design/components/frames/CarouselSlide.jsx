import React from 'react';
import { Wordmark } from '../core/Wordmark.jsx';
import { Eyebrow } from '../core/Eyebrow.jsx';
import { Hook } from '../core/Hook.jsx';
import { Body } from '../core/Body.jsx';
import { CTA } from '../core/CTA.jsx';
import { Firma } from '../core/Firma.jsx';

// Slide de carrusel IG 4:5 (lienzo 1080x1350) autoescalado a `width`.
export function CarouselSlide({ kind = 'punto', index, eyebrow, title, highlight, body, cta, width = 320, children, style }) {
  const s = width / 1080;
  const num = index != null ? String(index).padStart(2, '0') : null;
  let content;
  if (children) {
    content = <div style={{ position: 'absolute', inset: 0, padding: 90, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 50, boxSizing: 'border-box' }}>{children}</div>;
  } else if (kind === 'portada') {
    content = (
      <div style={{ position: 'absolute', inset: 0, padding: 90, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 60, boxSizing: 'border-box' }}>
        {eyebrow ? <Eyebrow size={30}>{eyebrow}</Eyebrow> : null}
        <Hook size={130} highlight={highlight}>{title}</Hook>
        <div style={{ position: 'absolute', right: 90, bottom: 100, fontFamily: 'var(--al-font-body)', fontWeight: 700, fontSize: 30, letterSpacing: '0.14em', textTransform: 'uppercase', color: 'var(--al-lima)' }}>Deslizá →</div>
      </div>
    );
  } else if (kind === 'cierre') {
    content = (
      <div style={{ position: 'absolute', inset: 0, padding: 90, display: 'flex', flexDirection: 'column', justifyContent: 'center', alignItems: 'center', textAlign: 'center', gap: 70, boxSizing: 'border-box' }}>
        <Hook size={110} highlight={highlight} style={{ justifyItems: 'center' }}>{title}</Hook>
        {cta ? <CTA size={32}>{cta}</CTA> : null}
        <Firma size={28} />
      </div>
    );
  } else {
    content = (
      <div style={{ position: 'absolute', inset: 0, padding: 90, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 50, boxSizing: 'border-box' }}>
        {num ? <div style={{ fontFamily: 'var(--al-font-display)', fontSize: 90, lineHeight: 1, color: 'var(--al-lima)' }}>{num}</div> : null}
        <Hook size={96} highlight={highlight}>{title}</Hook>
        {body ? <Body size={40} tone="muted" style={{ maxWidth: 860 }}>{body}</Body> : null}
      </div>
    );
  }
  return (
    <div style={{ width, height: Math.round(width * 1350 / 1080), position: 'relative', overflow: 'hidden', flex: 'none', ...style }}>
      <div style={{ width: 1080, height: 1350, transform: `scale(${s})`, transformOrigin: 'top left', position: 'absolute', top: 0, left: 0, background: 'var(--al-negro)', fontFamily: 'var(--al-font-body)' }}>
        {content}
        <div style={{ position: 'absolute', top: 80, left: 90, right: 90, display: 'flex', justifyContent: 'space-between', alignItems: 'center' }}>
          <Wordmark size={40} />
        </div>
      </div>
    </div>
  );
}
