Frame de historia IG 9:16 (lienzo 1080x1920 autoescalado): wordmark arriba, zonas seguras respetadas, 5 layouts.

```jsx
<StoryFrame kind="hook" eyebrow="Semana 12" title="Llevo 3 meses afilando cuchillos" highlight="sin prender la estufa." width={270} />
<StoryFrame kind="foto" imageUrl="..." title="Esto no cerró" sub="Y lo cuento igual." />
<StoryFrame kind="antes-despues" antes="Afinar el plan una semana más" despues="Publicar la versión imperfecta hoy" cta='Comentá "estufa"' />
<StoryFrame kind="quote" quote="El plan perfecto era mi forma de esconderme." />
<StoryFrame kind="cta" title="¿Te pasa lo mismo?" cta="Respondé esta historia" />
```

Reglas: una historia = un mensaje = un CTA; texto mínimo; foto real, nunca stock.
