import * as React from 'react';
/**
 * Slide de carrusel IG 4:5 (lienzo 1080x1350 autoescalado): portada, punto numerado o cierre con CTA.
 * @startingPoint section="Frames" subtitle="Carrusel IG 4:5 — portada, punto numerado, cierre" viewport="320x400"
 */
export interface CarouselSlideProps {
  /** 'portada' | 'punto' (default, numerado) | 'cierre' */
  kind?: 'portada' | 'punto' | 'cierre';
  /** Número del punto (se muestra como 01, 02…). */
  index?: number;
  eyebrow?: string;
  title?: string;
  /** Palabra(s) final(es) con marcador lima. */
  highlight?: string;
  /** Texto de apoyo (kind 'punto'). */
  body?: string;
  /** Copy del CTA (kind 'cierre'). */
  cta?: string;
  /** Ancho renderizado en px (alto = width*5/4). Default 320. */
  width?: number;
  /** Contenido libre (reemplaza el layout del kind). */
  children?: React.ReactNode;
  style?: React.CSSProperties;
}
export declare function CarouselSlide(props: CarouselSlideProps): JSX.Element;
