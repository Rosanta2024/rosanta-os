import React from 'react';
import { Wordmark } from '../core/Wordmark.jsx';
import { Eyebrow } from '../core/Eyebrow.jsx';
import { Hook } from '../core/Hook.jsx';
import { Body } from '../core/Body.jsx';
import { CTA } from '../core/CTA.jsx';
import { Firma } from '../core/Firma.jsx';
import { AntesDespues } from './AntesDespues.jsx';

// Lienzo 1080x1920 autoescalado a `width`. Zonas seguras: ~200px arriba, ~250px abajo.
export function StoryFrame({ kind = 'hook', eyebrow, title, highlight, sub, cta, imageUrl, antes, despues, quote, firma, width = 270, children, style }) {
  const s = width / 1080;
  const pad = '260px 90px 300px';
  const center = { position: 'absolute', inset: 0, padding: pad, display: 'flex', flexDirection: 'column', justifyContent: 'center', gap: 60, boxSizing: 'border-box' };
  const firmaEl = firma === false ? null : <Firma size={30}>{typeof firma === 'string' ? firma : undefined}</Firma>;
  let content;
  if (children) {
    content = <div style={center}>{children}</div>;
  } else if (kind === 'foto') {
    content = (
      <>
        <div style={{ position: 'absolute', inset: 0, background: imageUrl ? `url("${imageUrl}") center/cover no-repeat` : 'var(--al-gris-900)' }}></div>
        {!imageUrl && <div style={{ position: 'absolute', inset: 0, display: 'grid', placeItems: 'center', color: 'var(--al-blanco-40)', fontFamily: 'var(--al-font-body)', fontSize: 36 }}>Foto o video real aquí</div>}
        <div style={{ position: 'absolute', inset: 0, background: 'linear-gradient(180deg, rgba(10,10,10,0.45) 0%, rgba(10,10,10,0) 22%, rgba(10,10,10,0) 48%, rgba(10,10,10,0.92) 80%)' }}></div>
        <div style={{ position: 'absolute', left: 90, right: 90, bottom: 300, display: 'grid', gap: 44 }}>
          {eyebrow ? <Eyebrow size={30}>{eyebrow}</Eyebrow> : null}
          <Hook size={120} highlight={highlight}>{title}</Hook>
          {sub ? <Body size={40} tone="muted">{sub}</Body> : null}
        </div>
      </>
    );
  } else if (kind === 'antes-despues') {
    content = (
      <div style={center}>
        {eyebrow ? <Eyebrow size={30}>{eyebrow}</Eyebrow> : null}
        <AntesDespues antes={antes} despues={despues} size={72} />
        {cta ? <CTA size={30} style={{ alignSelf: 'flex-start', marginTop: 20 }}>{cta}</CTA> : firmaEl}
      </div>
    );
  } else if (kind === 'quote') {
    content = (
      <div style={center}>
        <div aria-hidden="true" style={{ width: 110, height: 10, background: 'var(--al-lima)' }}></div>
        <div style={{ fontFamily: 'var(--al-font-display)', fontSize: 110, lineHeight: 1.05, textTransform: 'uppercase', color: 'var(--al-blanco)', textWrap: 'balance' }}>{quote || title}</div>
        {firmaEl}
      </div>
    );
  } else if (kind === 'cta') {
    content = (
      <div style={{ ...center, alignItems: 'center', textAlign: 'center', gap: 70 }}>
        {eyebrow ? <Eyebrow size={30}>{eyebrow}</Eyebrow> : null}
        <Hook size={120} highlight={highlight} style={{ justifyItems: 'center' }}>{title}</Hook>
        {cta ? <CTA size={34}>{cta}</CTA> : null}
        {sub ? <Body size={36} tone="muted">{sub}</Body> : null}
      </div>
    );
  } else {
    content = (
      <div style={center}>
        {eyebrow ? <Eyebrow size={30}>{eyebrow}</Eyebrow> : null}
        <Hook size={140} highlight={highlight}>{title}</Hook>
        {sub ? <Body size={42} tone="muted" style={{ maxWidth: 840 }}>{sub}</Body> : null}
        {firmaEl}
      </div>
    );
  }
  return (
    <div style={{ width, height: Math.round(width * 1920 / 1080), position: 'relative', overflow: 'hidden', flex: 'none', ...style }}>
      <div style={{ width: 1080, height: 1920, transform: `scale(${s})`, transformOrigin: 'top left', position: 'absolute', top: 0, left: 0, background: 'var(--al-negro)', fontFamily: 'var(--al-font-body)' }}>
        {content}
        <div style={{ position: 'absolute', top: 120, left: 90, right: 90 }}>
          <Wordmark size={44} />
        </div>
      </div>
    </div>
  );
}
