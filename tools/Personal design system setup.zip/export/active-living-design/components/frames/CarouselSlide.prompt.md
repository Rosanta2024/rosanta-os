Slide de carrusel IG 4:5: cada slide funciona sola (screenshot-able); un carrusel = un argumento.

```jsx
<CarouselSlide kind="portada" eyebrow="Mindset" title="Por qué preparar" highlight="no es avanzar" />
<CarouselSlide index={1} title="El plan se siente productivo" body="Afilar cuchillos da la misma dopamina que cocinar. Pero no alimenta." />
<CarouselSlide kind="cierre" title="¿Cuál es tu estufa apagada?" cta="Comentá y te leo" />
```
