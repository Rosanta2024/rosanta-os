import * as React from 'react';
/** Bloque antes→después: el patrón viejo tachado (muted) y el corregido en grande, unidos por la flecha lima. */
export interface AntesDespuesProps {
  /** El patrón viejo (se muestra tachado y apagado). */
  antes?: string;
  /** El patrón corregido. */
  despues?: string;
  /** 'column' (default, con ↓) | 'row' (con →) */
  dir?: 'column' | 'row';
  tone?: 'light' | 'dark';
  /** Tamaño del texto principal en px. Default 30 (64-72 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function AntesDespues(props: AntesDespuesProps): JSX.Element;
