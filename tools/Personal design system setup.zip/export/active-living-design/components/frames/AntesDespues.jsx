import React from 'react';

export function AntesDespues({ antes, despues, dir = 'column', tone = 'light', size = 30, style }) {
  const textColor = tone === 'dark' ? 'var(--al-negro)' : 'var(--al-blanco)';
  const muted = tone === 'dark' ? 'var(--al-negro-70)' : 'var(--al-blanco-40)';
  const labelSize = Math.max(11, Math.round(size * 0.42));
  const block = (label, text, isAntes) => (
    <div style={{ display: 'grid', gap: Math.round(size * 0.35), flex: 1 }}>
      <div style={{ fontFamily: 'var(--al-font-body)', fontWeight: 700, fontSize: labelSize, letterSpacing: '0.2em', textTransform: 'uppercase', color: isAntes ? muted : 'var(--al-lima)' }}>{label}</div>
      <div style={{ fontFamily: 'var(--al-font-display)', fontWeight: 400, fontSize: size, lineHeight: 1.08, textTransform: 'uppercase', color: isAntes ? muted : textColor, textDecoration: isAntes ? 'line-through' : 'none', textDecorationColor: 'var(--al-lima)', textDecorationThickness: Math.max(2, Math.round(size * 0.08)), textWrap: 'balance' }}>{text}</div>
    </div>
  );
  return (
    <div style={{ display: 'flex', flexDirection: dir, gap: Math.round(size * 0.9), ...style }}>
      {block('Antes', antes, true)}
      <div aria-hidden="true" style={{ fontFamily: 'var(--al-font-display)', fontSize: Math.round(size * 1.1), lineHeight: 1, color: 'var(--al-lima)', alignSelf: dir === 'row' ? 'center' : 'flex-start' }}>{dir === 'row' ? '→' : '↓'}</div>
      {block('Después', despues, false)}
    </div>
  );
}
