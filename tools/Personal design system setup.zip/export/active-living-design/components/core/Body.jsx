import React from 'react';

export function Body({ children, tone = 'light', size = 17, style }) {
  const color = tone === 'dark' ? 'var(--al-negro)' : tone === 'muted' ? 'var(--al-blanco-70)' : 'var(--al-blanco)';
  return (
    <p style={{ margin: 0, fontFamily: 'var(--al-font-body)', fontWeight: 400, fontSize: size, lineHeight: 1.55, color, textWrap: 'pretty', ...style }}>{children}</p>
  );
}
