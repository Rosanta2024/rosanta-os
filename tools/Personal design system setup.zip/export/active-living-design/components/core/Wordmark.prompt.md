Wordmark tipográfico de la marca (ACTIVE blanco + LIVING lima, Anton); usar en la esquina superior de frames y como firma de marca.

```jsx
<Wordmark size={22} />
<Wordmark variant="dark" />  // sobre fondo blanco
```

Variants: `light` (default, sobre negro), `dark`, `mono`. `size` en px (40 en lienzos 1080px).
