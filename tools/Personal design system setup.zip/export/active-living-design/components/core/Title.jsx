import React from 'react';

export function Title({ children, highlight, size = 44, tone = 'light', align, style }) {
  const color = tone === 'dark' ? 'var(--al-negro)' : 'var(--al-blanco)';
  return (
    <h2 style={{ margin: 0, fontFamily: 'var(--al-font-display)', fontWeight: 400, fontSize: size, lineHeight: 1.05, textTransform: 'uppercase', letterSpacing: '0.01em', color, textAlign: align, textWrap: 'balance', ...style }}>
      {children}
      {highlight ? <> <span style={{ background: 'var(--al-lima)', color: 'var(--al-negro)', padding: '0.02em 0.12em', boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }}>{highlight}</span></> : null}
    </h2>
  );
}
