Sign-off de marca que cierra una pieza; default "→ Lo hago de todos modos."

```jsx
<Firma />
<Firma size={30}>No abro nada nuevo sin cerrar algo primero.</Firma>
```
