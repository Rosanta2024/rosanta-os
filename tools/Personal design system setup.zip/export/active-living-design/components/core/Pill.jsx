import React from 'react';

export function Pill({ children, tone = 'blanco', size = 12, style }) {
  const tones = {
    blanco: { color: 'var(--al-blanco)', borderColor: 'var(--al-blanco)', background: 'transparent' },
    lima: { color: 'var(--al-lima)', borderColor: 'var(--al-lima)', background: 'transparent' },
    negro: { color: 'var(--al-negro)', borderColor: 'var(--al-negro)', background: 'transparent' },
    solid: { color: 'var(--al-negro)', borderColor: 'var(--al-lima)', background: 'var(--al-lima)' },
  };
  const t = tones[tone] || tones.blanco;
  return (
    <span style={{ display: 'inline-block', fontFamily: 'var(--al-font-body)', fontWeight: 600, fontSize: size, letterSpacing: '0.12em', textTransform: 'uppercase', padding: '0.5em 1em', border: '1.5px solid', borderRadius: 0, lineHeight: 1.2, ...t, ...style }}>{children}</span>
  );
}
