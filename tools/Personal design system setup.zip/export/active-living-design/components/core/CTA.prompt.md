CTA plano con flecha; una pieza = un CTA. Copy específico y accionable ("Comentá 'estufa'"), nunca "saber más".

```jsx
<CTA>Comentá "estufa"</CTA>
<CTA variant="ghost" arrow={false}>Respondé esta historia</CTA>
```

Variants: `primary` (lima), `ghost` (outline), `inverse` (blanco), `dark` (negro sobre claro/lima).
