Hook gigante que abre una pieza (el primer golpe de la historia); frase corta, honesta, que interrumpe el patrón.

```jsx
<Hook kicker="Semana 12" highlight="sin prender la estufa.">Llevo 3 meses afilando cuchillos</Hook>
```

Niveles de hook (ver guidelines/hooks.html): pausa, interés, promesa, acción. Una frase, un mensaje.
