import * as React from 'react';
/** Tag/etiqueta rectangular con borde (radius 0). */
export interface PillProps {
  children?: React.ReactNode;
  /** 'blanco' (default) | 'lima' | 'negro' | 'solid' (fondo lima) */
  tone?: 'blanco' | 'lima' | 'negro' | 'solid';
  /** Tamaño de fuente en px. Default 12. */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Pill(props: PillProps): JSX.Element;
