import React from 'react';
import { Eyebrow } from './Eyebrow.jsx';

export function Hook({ children, highlight, kicker, size = 72, tone = 'light', style }) {
  const color = tone === 'dark' ? 'var(--al-negro)' : 'var(--al-blanco)';
  return (
    <div style={{ display: 'grid', gap: Math.round(size * 0.28), ...style }}>
      {kicker ? <Eyebrow tone={tone === 'dark' ? 'negro' : 'lima'} size={Math.round(size * 0.2)}>{kicker}</Eyebrow> : null}
      <div style={{ fontFamily: 'var(--al-font-display)', fontWeight: 400, fontSize: size, lineHeight: 1.0, textTransform: 'uppercase', letterSpacing: '0.01em', color, textWrap: 'balance' }}>
        {children}
        {highlight ? <> <span style={{ background: 'var(--al-lima)', color: 'var(--al-negro)', padding: '0.02em 0.12em', boxDecorationBreak: 'clone', WebkitBoxDecorationBreak: 'clone' }}>{highlight}</span></> : null}
      </div>
    </div>
  );
}
