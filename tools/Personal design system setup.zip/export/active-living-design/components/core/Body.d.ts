import * as React from 'react';
/** Párrafo de cuerpo en Archivo 400. */
export interface BodyProps {
  children?: React.ReactNode;
  /** 'light' (blanco, default) | 'muted' (blanco 70%) | 'dark' (negro) */
  tone?: 'light' | 'muted' | 'dark';
  /** Tamaño en px. Default 17 (38-42 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Body(props: BodyProps): JSX.Element;
