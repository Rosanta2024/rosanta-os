import React from 'react';

export function Eyebrow({ children, tone = 'lima', size = 13, style }) {
  const color = tone === 'blanco' ? 'var(--al-blanco)' : tone === 'negro' ? 'var(--al-negro)' : 'var(--al-lima)';
  return (
    <div style={{ fontFamily: 'var(--al-font-body)', fontWeight: 700, fontSize: size, letterSpacing: '0.22em', textTransform: 'uppercase', color, display: 'flex', alignItems: 'center', gap: '0.8em', lineHeight: 1, ...style }}>
      <span aria-hidden="true" style={{ width: '1.8em', height: '0.14em', minHeight: 2, background: 'currentColor', flex: 'none' }}></span>
      <span>{children}</span>
    </div>
  );
}
