import * as React from 'react';
/** Botón/CTA plano con flecha: lima sobre negro (primary), outline (ghost), blanco (inverse) o negro (dark). */
export interface CTAProps {
  children?: React.ReactNode;
  /** 'primary' (lima, default) | 'ghost' (outline blanco) | 'inverse' (blanco) | 'dark' (negro) */
  variant?: 'primary' | 'ghost' | 'inverse' | 'dark';
  /** Muestra la flecha →. Default true. */
  arrow?: boolean;
  href?: string;
  onClick?: () => void;
  /** Tamaño de fuente en px. Default 14 (30-34 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function CTA(props: CTAProps): JSX.Element;
