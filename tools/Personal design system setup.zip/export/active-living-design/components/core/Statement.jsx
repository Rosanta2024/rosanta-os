import React from 'react';
import { Firma } from './Firma.jsx';

export function Statement({ children, firma, tone = 'light', size = 40, style }) {
  const color = tone === 'dark' ? 'var(--al-negro)' : 'var(--al-blanco)';
  return (
    <figure style={{ margin: 0, display: 'grid', gap: Math.round(size * 0.5), ...style }}>
      <div aria-hidden="true" style={{ width: Math.round(size * 1.2), height: Math.max(3, Math.round(size * 0.1)), background: 'var(--al-lima)' }}></div>
      <blockquote style={{ margin: 0, fontFamily: 'var(--al-font-display)', fontWeight: 400, fontSize: size, lineHeight: 1.08, textTransform: 'uppercase', color, textWrap: 'balance' }}>{children}</blockquote>
      {firma ? <Firma tone={tone} size={Math.round(size * 0.35)}>{firma === true ? undefined : firma}</Firma> : null}
    </figure>
  );
}
