Tag rectangular de borde duro para categorías o series ("Semana 12", "Mindset").

```jsx
<Pill>Mindset</Pill>
<Pill tone="solid">Semana 12</Pill>
```
