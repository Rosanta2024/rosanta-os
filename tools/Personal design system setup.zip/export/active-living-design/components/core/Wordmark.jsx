import React from 'react';

export function Wordmark({ variant = 'light', size = 22, style }) {
  const base = variant === 'dark' ? 'var(--al-negro)' : 'var(--al-blanco)';
  const accent = variant === 'mono' ? base : 'var(--al-lima)';
  return (
    <div style={{ fontFamily: 'var(--al-font-display)', fontWeight: 400, fontSize: size, letterSpacing: '0.04em', textTransform: 'uppercase', lineHeight: 1, color: base, whiteSpace: 'nowrap', ...style }}>
      Active&nbsp;<span style={{ color: accent }}>Living</span>
    </div>
  );
}
