import React from 'react';

export function CTA({ children, variant = 'primary', arrow = true, href, onClick, size = 14, style }) {
  const variants = {
    primary: { background: 'var(--al-lima)', color: 'var(--al-negro)', borderColor: 'var(--al-lima)' },
    ghost: { background: 'transparent', color: 'var(--al-blanco)', borderColor: 'var(--al-blanco)' },
    inverse: { background: 'var(--al-blanco)', color: 'var(--al-negro)', borderColor: 'var(--al-blanco)' },
    dark: { background: 'var(--al-negro)', color: 'var(--al-blanco)', borderColor: 'var(--al-negro)' },
  };
  const v = variants[variant] || variants.primary;
  const Tag = href ? 'a' : 'button';
  return (
    <Tag href={href} onClick={onClick} style={{ display: 'inline-flex', alignItems: 'center', gap: '0.7em', fontFamily: 'var(--al-font-body)', fontWeight: 700, fontSize: size, letterSpacing: '0.1em', textTransform: 'uppercase', padding: '1em 1.6em', border: '2px solid', borderRadius: 0, cursor: 'pointer', textDecoration: 'none', lineHeight: 1, ...v, ...style }}>
      <span>{children}</span>
      {arrow ? <span aria-hidden="true">→</span> : null}
    </Tag>
  );
}
