import * as React from 'react';
/** Hook gigante que abre una pieza: Anton uppercase enorme, con kicker opcional y marcador lima. */
export interface HookProps {
  children?: React.ReactNode;
  /** Palabra(s) final(es) con marcador lima. */
  highlight?: string;
  /** Eyebrow corto encima del hook. */
  kicker?: string;
  /** Tamaño en px. Default 72 (120-150 en lienzos 1080px). */
  size?: number;
  tone?: 'light' | 'dark';
  style?: React.CSSProperties;
}
export declare function Hook(props: HookProps): JSX.Element;
