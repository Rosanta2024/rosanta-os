import * as React from 'react';
/** Título de sección en Anton uppercase. `highlight` agrega la palabra clave con marcador lima (elemento firma). */
export interface TitleProps {
  children?: React.ReactNode;
  /** Palabra(s) final(es) resaltadas con marcador lima. */
  highlight?: string;
  /** Tamaño en px. Default 44. */
  size?: number;
  /** 'light' (texto blanco, default) | 'dark' (texto negro sobre claro) */
  tone?: 'light' | 'dark';
  align?: 'left' | 'center' | 'right';
  style?: React.CSSProperties;
}
export declare function Title(props: TitleProps): JSX.Element;
