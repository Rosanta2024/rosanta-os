Párrafo de cuerpo en Archivo; frases cortas, concretas, sin humo.

```jsx
<Body>Esta semana no cerré el evento. Le tuve miedo al precio.</Body>
<Body tone="muted" size={15}>Contexto secundario en blanco 70%.</Body>
```
