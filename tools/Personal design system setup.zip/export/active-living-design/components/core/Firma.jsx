import React from 'react';

export function Firma({ children = 'Lo hago de todos modos.', tone = 'light', size = 14, style }) {
  const color = tone === 'dark' ? 'var(--al-negro)' : 'var(--al-lima)';
  return (
    <div style={{ fontFamily: 'var(--al-font-body)', fontWeight: 700, fontSize: size, letterSpacing: '0.14em', textTransform: 'uppercase', color, display: 'flex', gap: '0.6em', alignItems: 'center', lineHeight: 1, ...style }}>
      <span aria-hidden="true" style={{ color: 'var(--al-lima)' }}>→</span>
      <span>{children}</span>
    </div>
  );
}
