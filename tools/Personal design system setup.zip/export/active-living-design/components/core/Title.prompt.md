Título de sección en Anton uppercase; `highlight` pinta la palabra clave con el marcador lima (gesto firma de la marca).

```jsx
<Title highlight="prendé la estufa.">Dejá de preparar.</Title>
<Title tone="dark" size={36}>Sobre fondo claro</Title>
```

El highlight va al final del texto. No abusar: un highlight por pieza.
