import * as React from 'react';
/** Kicker corto sobre un título: Archivo bold uppercase con tracking amplio y guion de color. */
export interface EyebrowProps {
  children?: React.ReactNode;
  /** 'lima' (default) | 'blanco' | 'negro' */
  tone?: 'lima' | 'blanco' | 'negro';
  /** Tamaño de fuente en px. Default 13 (30 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Eyebrow(props: EyebrowProps): JSX.Element;
