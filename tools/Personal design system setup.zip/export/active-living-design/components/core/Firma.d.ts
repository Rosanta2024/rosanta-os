import * as React from 'react';
/** Sign-off de marca: "→ Lo hago de todos modos." (default). Cierra piezas y frames. */
export interface FirmaProps {
  /** Frase firma. Default "Lo hago de todos modos." */
  children?: React.ReactNode;
  /** 'light' (lima, default) | 'dark' (negro sobre claro, flecha lima) */
  tone?: 'light' | 'dark';
  /** Tamaño en px. Default 14 (30 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Firma(props: FirmaProps): JSX.Element;
