Kicker corto que antecede a un título (2-4 palabras, uppercase, con guion lima).

```jsx
<Eyebrow>El sistema, en vivo</Eyebrow>
<Eyebrow tone="blanco" size={30}>Semana 12</Eyebrow>
```

Tones: `lima` (default), `blanco`, `negro` (sobre fondo claro o lima).
