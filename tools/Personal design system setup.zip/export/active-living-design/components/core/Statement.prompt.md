Statement/quote grande (el póster de la marca): barra lima, Anton uppercase, firma opcional.

```jsx
<Statement firma>Preparar se siente como avanzar. El plato nunca sale.</Statement>
<Statement firma="No abro nada nuevo sin cerrar algo primero.">El plan perfecto era mi forma de esconderme.</Statement>
```
