import * as React from 'react';
/** Wordmark tipográfico de Active Living (no hay logo gráfico). ACTIVE en base + LIVING en lima. */
export interface WordmarkProps {
  /** 'light' (sobre negro, default) | 'dark' (sobre blanco) | 'mono' (un solo color base) */
  variant?: 'light' | 'dark' | 'mono';
  /** Tamaño de fuente en px. Default 22. */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Wordmark(props: WordmarkProps): JSX.Element;
