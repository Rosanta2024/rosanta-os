import * as React from 'react';
/** Statement/quote grande: barra lima + Anton uppercase + firma opcional. El póster de la marca. */
export interface StatementProps {
  children?: React.ReactNode;
  /** Firma bajo el statement: `true` usa la default ("Lo hago de todos modos."), o pasar un string. */
  firma?: boolean | string;
  tone?: 'light' | 'dark';
  /** Tamaño en px. Default 40 (100-120 en lienzos 1080px). */
  size?: number;
  style?: React.CSSProperties;
}
export declare function Statement(props: StatementProps): JSX.Element;
