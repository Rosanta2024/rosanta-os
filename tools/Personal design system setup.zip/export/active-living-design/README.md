# Active Living — Design System

Marca personal de Juanma Lemus (Antigua Guatemala). Contenido de vida personal y mindset: la trampa de la preparación-sobre-acción, documentada con honestidad desde el proceso real. Construido con el formato anti-brand + visual storytelling (fuentes de referencia del usuario en `uploads/`: Anti-Brand Sprint Workbook y The Art of Visual Storytelling Playbook, The Passive Rebel — usados solo como marco metodológico; todo el contenido aquí es original).

Canal principal: Instagram (historias 9:16, carruseles 4:5, portadas de reels). Secundario: presentaciones y one-pagers.

## El anti-brand en 5 pilares

### 1. El enemigo
**Enamorarse del plan para no arriesgarse con la acción.** El cocinero que se pasa la mañana afilando cuchillos, reorganizando la despensa y perfeccionando la receta… y nunca prende la estufa. Preparar se siente como avanzar, pero el plato nunca sale. Todo el contenido pelea contra eso.

### 2. Atmósfera — 3 emociones objetivo
1. "Este hombre es honesto hasta cuando le cuesta." — se vende el proceso real: el evento que no cerró, la venta que falló, el precio que dio miedo.
2. "Yo tengo el mismo problema que él." — nombrar la trampa de preparar-sin-ejecutar hace que la gente ambiciosa se sienta vista. Es el gancho emocional más fuerte.
3. "Quiero saber cómo lo está resolviendo." — el método se muestra vivo, no como producto terminado.

### 3. Arquetipo
Creador + Sabio: construye en público y desmenuza lo que aprende. Nunca gurú.

### 4. Voz (CONTENT FUNDAMENTALS)
- Directo, honesto, concreto. Nombra el problema real aunque lo deje mal parado.
- Empuja a la acción, no a la teoría.
- Metáforas de cocina y de trabajo diario para bajar ideas grandes a tierra ("prender la estufa", "el plato nunca sale").
- Primera persona, español guatemalteco natural (vos/tú según canal). Sin emoji en piezas de marca; permitidos con moderación en captions.
- **Nunca:** lenguaje aspiracional, humo, frases de calendario, motivación genérica, promesas de éxito fácil, vocabulario de gurú ("sumérgete", "eleva tu potencial"), em dashes.
- Frases firma: **"No abro nada nuevo sin cerrar algo primero."** / **"Lo hago de todos modos."** (cierre/sign-off).
- Hooks en 4 niveles: pausa → interés → promesa → acción. Ejemplos en `guidelines/hooks.html`.
- Arco de historia: Setup → Struggle → Shift → Solution → Result. La audiencia es el héroe; Juanma es el guía que va un paso adelante.
- Una pieza = un mensaje = un CTA.

### 5. Vibe visual (VISUAL FOUNDATIONS)
- **Color:** negro `#0A0A0A` dominante (dark-first), blanco para texto, **lima `#C6F542` como única chispa** — highlight tipo marcador, flechas, CTAs, labels. Nunca lima como fondo de superficie grande. Fotos: reales, crudas, de preferencia B/N o desaturadas; el lima es lo único que grita.
- **Tipografía:** Anton (display, siempre MAYÚSCULAS, interlineado apretado ~1.0) para hooks, títulos y statements. Archivo para cuerpo (400) y labels/eyebrows/CTAs (600-700, uppercase, tracking amplio).
- **Forma:** plano, esquinas duras (radius 0), bordes de 2px, sin sombras, sin degradados decorativos (solo gradiente de protección sobre foto). Sin blobs ni formas orgánicas.
- **Elementos firma:** (1) highlight lima tipo marcador sobre la palabra clave del título; (2) la flecha `→` (y `↓` en vertical) como único glifo decorativo — motivo antes→después; (3) el sign-off "Lo hago de todos modos."
- **Layout:** aire generoso, composición confiada, texto grande alineado a la izquierda por defecto. Historias con zonas seguras (arriba ~200px, abajo ~250px en lienzo 1080×1920).
- **Animación:** cortes secos o fades rápidos; nada de bounces.
- **Hover/press (web):** hover = invertir (lima↔negro) u opacidad 0.85; press = sin shrink.
- **Imperfección > pulido:** se prefiere la foto real de la cocina/el trabajo a stock. Nunca stock genérico de oficina.

## ICONOGRAPHY
No hay set de íconos. Los únicos glifos son caracteres unicode: `→`, `↓`, `/`. Sin emoji en piezas visuales. No se dibujan íconos SVG; si algún día se necesita un set, usar Lucide (stroke 2px) y documentarlo aquí. **No existe logo gráfico** — la marca se escribe en tipografía (componente `Wordmark`: ACTIVE en blanco + LIVING en lima, Anton). No crear logo sin material del usuario.

## Tokens
`tokens/colors.css`, `tokens/typography.css`, `tokens/spacing.css` — prefijo `--al-*`. Entrada única: `styles.css`.

**Fuentes:** Anton y Archivo (variable) viven en `fonts/` como .ttf locales (licencia OFL, copiados de google/fonts) — el skill funciona offline.

## Índice
- `styles.css` — entrada CSS (importa tokens + fonts).
- `tokens/` — colores, tipografía, espaciado.
- `guidelines/` — specimen cards (colores, tipo, espaciado, voz, enemigo, hooks).
- `components/core/` — Wordmark, Eyebrow, Title, Hook, Body, Statement, CTA, Pill, Firma.
- `components/frames/` — StoryFrame (9:16), CarouselSlide (4:5), AntesDespues.
- `notes/metodologia-referencia.md` — resumen del marco metodológico.
- `SKILL.md` — uso como Agent Skill.

## Intentional additions
Sistema creado desde cero (sin inventario fuente): el set de componentes se dimensionó a los usos pedidos (historias, carruseles, portadas, docs). `AntesDespues` se agregó porque el formato antes→después es el patrón natural del contenido.
